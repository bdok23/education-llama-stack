import main
print('Backend environment setup successful!')
